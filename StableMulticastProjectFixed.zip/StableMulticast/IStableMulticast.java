package StableMulticast;

public interface IStableMulticast {
    void deliver(String msg);
}
